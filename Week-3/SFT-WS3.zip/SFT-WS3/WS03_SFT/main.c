#define _CRT_SECURE_NO_WARNINGS 
#include <stdio.h>
#include "Address.h"


int main()
{
	//char firstName[NAME_LIMIT];
	////char firstName[] = { "John"};
	//printf("Enter your first name: ");
	//fgets(firstName, NAME_LIMIT, stdin);

	//printf("You entered:");
	//printf("%s \n", firstName);

	return 0;
}