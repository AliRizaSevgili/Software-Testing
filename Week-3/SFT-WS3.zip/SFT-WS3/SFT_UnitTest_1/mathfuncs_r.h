#pragma once
#ifndef MATHFUNCS_R_H
#define MATHFUNCS_R_H

extern "C"
{
#include <mathfuncs.h>
}

#endif