# Win23_SFT221_NCC_5
This is the git repository for Milestone project of Winter 2023 SFT221 NCC Group 5

Directory structure:
1. contract: Where the contract file is located
2. function-specification: Where you will find function specification document
3. hook: Where you will find the hook file
4. project-sourcecode: You will find all the programs here. Please use the ".sln" file to open the program project.
						1. truck-project
						2. blackbox testing
						3. whitebox testing
						4. integration testing
5. scrum: All the scrum reports
6. trace-matrix: All version of traceability matrix