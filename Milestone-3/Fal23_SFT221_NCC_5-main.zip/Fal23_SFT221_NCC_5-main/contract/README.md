# Contract
This is the directory for storing contracts. 
Please sign your own contract and name the contract file:
group5-contract-your name.docx
