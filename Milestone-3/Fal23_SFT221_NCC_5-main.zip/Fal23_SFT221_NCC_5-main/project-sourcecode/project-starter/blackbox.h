#ifndef BLACKBOX_H
#define BLACKBOX_H

#include <stdio.h>
#include <assert.h>
#include "truck.h"
#include "shipment.h"

// master test function for truck
int testTruck();
int testSpace();
int testWeight();
int testAddPackage();

// master test function for shipment
int testShipment();
#endif