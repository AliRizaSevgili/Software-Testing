#ifndef TRUCK_H
#define TRUCK_H

#define TRUCK_MAX_WEIGHT 1500
#define TRUCK_MAX_SIZE 48

#include "shipment.h"
#include "mapping.h"

struct Truck
{
    /// @brief in kg
    /// Use TRUCK_MAX_WEIGHT to get the limit
    int weight;
    /// @brief cubic meters
    /// Use TRUCK_MAX_SIZE to get the limit
    double size;
    /// @brief Contains the loaded boxes
    struct Shipment payloads[99];
    /// @brief Current position
    struct Point position;
    /// @brief Route taken by this truck
    struct Route route;
};

// Function prototype
int findTruckForShipment(const struct Map *map, const struct Truck trucks[], const int numTrucks, const struct Shipment shipment);

#endif