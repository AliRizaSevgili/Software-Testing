#include "shipment.h"
#include "truck.h"
#include "mapping.h"

#include <limits.h>

// Function prototype
int findTruckForShipment(const struct Map *map, const struct Truck trucks[], const int numTrucks, const struct Shipment shipment);

// Implementation of the findTruckForShipment function
int findTruckForShipment(const struct Map *map, const struct Truck trucks[], const int numTrucks, const struct Shipment shipment)
{
    // Initialize variables to store the best truck index and the minimum distance
    int bestTruckIndex = -1;
    double minDistance = INT_MAX;

    // Iterate through each truck to find the best one for the shipment
    for (int i = 0; i < numTrucks; i++)
    {
        // Check if the truck can accommodate the shipment based on weight and size
        if (trucks[i].weight + shipment.weight <= TRUCK_MAX_WEIGHT &&
            trucks[i].size + shipment.boxSize <= TRUCK_MAX_SIZE)
        {

            // Calculate the distance from the truck's current position to the shipment destination
            struct Point truckPosition = trucks[i].position;
            struct Point shipmentDestination = shipment.destination;
            struct Route route = shortestPath(map, truckPosition, shipmentDestination);
            double distance = (double)route.numPoints;

            // Check if this truck has a shorter distance than the current minimum
            if (distance < minDistance)
            {
                minDistance = distance;
                bestTruckIndex = i;
            }
        }
    }

    // Return the index of the best truck for the shipment (-1 if no suitable truck is found)
    return bestTruckIndex;
}
