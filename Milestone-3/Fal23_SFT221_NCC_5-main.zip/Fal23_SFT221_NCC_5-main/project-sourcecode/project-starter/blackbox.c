#include <stdio.h>
#include "mapping.h"

/**
 * Test Case 1: populateMapTest()
 * This function tests whether the populateMap function creates a map
 * with the correct number of rows and columns.
 */
void populateMapTest()
{
    struct Map map = populateMap(); // Calling populateMap to create a map

    // Verify the number of rows and columns
    if (map.numRows == 25 && map.numCols == 25)
        printf("populateMapTest: PASSED!\n"); // Test passes if map has 25 rows and 25 columns
    else
        printf("populateMapTest: FAILED!\n"); // Test fails otherwise
    printf("\n");
}

/**
 * Helper function to check if the map coordinates are correct.
 * This function checks if the map's row and column numbers are within the expected range.
 *
 * @param map The map to be checked.
 * @return Returns 1 if coordinates are correct, 0 otherwise.
 */
int mapCoordinatesCheck(const struct Map *map)
{
    int rowMax = map->numRows;
    int colMax = map->numCols;

    // Check each row and column to ensure they are within valid range
    for (int r = 0; r < rowMax; r++)
    {
        if (r + 1 < 1 || r + 1 > 25)
        {
            printf("Row coordinate out of range: %d\n", r + 1);
            return 0;
        }
        for (int c = 0; c < colMax; c++)
        {
            if (c < 0 || c >= 25)
            {
                printf("Column coordinate out of range: %d\n", c);
                return 0;
            }
        }
    }
    return 1;
}

/**
 * Helper function to print the map.
 * This function prints the map's layout on the console using specified symbols.
 *
 * @param map The map to be printed.
 */
void testPrintMap(const struct Map *map)
{
    char symbols[] = " XB?G?.?Y?-?*?+?P"; // Symbols representing different map elements
    int rowMax = map->numRows;

    // Print column headers
    printf("%4s", " ");
    for (int c = 0; c < map->numCols; c++)
    {
        printf("%c", 'A' + c);
    }
    printf("\n");
    printf("%4s", " ");
    for (int c = 0; c < map->numCols; c++)
    {
        printf("-");
    }
    printf("\n");

    // Print each row of the map with corresponding symbols
    for (int r = 1; r <= rowMax; r++)
    {
        printf("%3d|", r);
        for (int c = 0; c < map->numCols; c++)
        {
            printf("%c", symbols[map->squares[r - 1][c]]);
        }
        printf("\n");
    }
}

/**
 * Test function for printMap.
 * This function tests printMap with different parameters and checks if the map coordinates are correct.
 */
void printMapTest()
{
    // Test case 1: base1 = 1, alphaCols = 1
    struct Map map1 = populateMap(); // Create a new map for testing
    printf("*** PrintMap Test case 1:\n");
    printMap(&map1, 1, 1); // Test with both base1 and alphaCols set to 1
    printf("\n");
    if (mapCoordinatesCheck(&map1))
        printf(": printMap Test case 1 PASSED!\n\n");
    else
        printf(": printMap Test case 1 FAILED!\n\n");

    // Test case 2: base1 = 10, alphaCols = 0
    struct Map map2 = populateMap();
    printf("*** PrintMap Test case 2:\n");
    printMap(&map2, 10, 0); // Test with base1 = 10 and alphaCols = 0
    printf("\n");
    if (!mapCoordinatesCheck(&map2))
        printf(": printMap Test case 2 PASSED!\n\n");
    else
        printf(": printMap Test case 2 FAILED!\n\n");

    // Test case 3: base1 = 20, alphaCols = 1
    struct Map map3 = populateMap();
    printf("*** PrintMap Test case 3:\n");
    printMap(&map3, 20, 1); // Test with base1 = 20 and alphaCols = 1
    printf("\n");
    if (!mapCoordinatesCheck(&map3))
        printf(": printMap Test case 3 PASSED!\n\n");
    else
        printf(": printMap Test case 3 FAILED!\n\n");
}

int main()
{
    populateMapTest(); // Run populateMapTest
    printMapTest();    // Run printMapTest
    return 0;
}
